#!/usr/bin/env python3
#to set it executable in UNIX
# -*- coding: utf-8 -*-
for i in range(2,22):
   print("El cuadrado de ",i,"es: ",i*i)

print ("eso es todo amigos")